<?php include('header.php');?>
<div class="inner cover">
<h2 class="cover-heading">Presentación del tema</h2>
<p class="lead">Loren ipsum dolor sit amet.</p>
</div>
<?php include('footer.php');?>
